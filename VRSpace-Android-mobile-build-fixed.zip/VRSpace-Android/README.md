# VR Space — Android / VR Box

Projeto Android Kotlin para um primeiro protótipo funcional de realidade mista para celulares usados em um visor VR Box.

## O que esta versão inclui no código

- Cena em tela cheia, com opção de desenho lado a lado para os dois olhos (interface plana duplicada para Cardboard; ainda não é renderização 3D com profundidade).
- Modo MR com câmera traseira como passthrough, quando o visor deixa a lente da câmera livre.
- Rastreamento de até duas mãos com MediaPipe Hand Landmarker e CameraX.
- Esqueleto de 21 pontos por mão desenhado sobre a câmera.
- Pinça entre polegar e indicador convertida em toque na interface.
- Janelas WebView independentes para DuckDuckGo, YouTube e jogos HTML5.
- Teclado virtual na tela para pesquisas sem depender do teclado de sistema.
- Até quatro janelas abertas no mesmo espaço.

## Limitação física importante do VR Box

O VR Space usa a câmera traseira para mostrar o ambiente real e localizar as mãos. Muitos VR Box fecham a parte traseira do celular e bloqueiam essa câmera. O hand tracking e o passthrough só funcionarão se houver uma abertura/alinhamento para a câmera traseira. Não corte nem modifique o visor sem avaliar o risco para o aparelho e para os olhos. Se a câmera ficar bloqueada, o menu, o navegador, YouTube e os jogos continuam disponíveis, mas sem passthrough ou hand tracking.

## Construir o APK

1. Instale o Android Studio (Hedgehog ou mais recente), Android SDK 35 e JDK 17.
2. Abra esta pasta (`VRSpace-Android`) no Android Studio.
3. Aguarde o Gradle Sync. O Gradle baixa automaticamente o modelo `hand_landmarker.task` do armazenamento oficial do MediaPipe durante o `preBuild`.
4. Escolha **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.
6. Instale no celular, permita o uso da câmera e teste primeiro sem colocar o aparelho dentro do VR Box, para confirmar se a câmera consegue enxergar as mãos.

## Uso

- **PESQUISA** abre DuckDuckGo.
- **YOUTUBE** abre o site oficial do YouTube no WebView do Android. Toque no player para iniciar a reprodução; o app não tenta remover anúncios ou restrições do YouTube.
- **JOGOS** abre o catálogo de jogos HTML5 do itch.io. Os jogos rodam como páginas da web e a compatibilidade varia por jogo.
- **＋ JANELA** abre outra janela independente.
- **⌨ TECLADO** mostra o teclado virtual do VR Space; o botão BUSCAR pesquisa no app atualmente ativo.
- **VR / MR** alterna entre a cena duplicada lado a lado e a tela única.
- **CÂMERA** mostra ou esconde o passthrough. A câmera pode continuar ativa para rastrear as mãos.
- Faça uma pinça juntando a ponta do polegar com a do indicador para enviar um toque no ponto da mão.

## Notas de implementação

MediaPipe executa a inferência localmente no dispositivo. Os quadros de câmera são processados em memória; este projeto não salva fotos ou vídeos. O modelo é incluído no APK durante o build. A versão de YouTube usa o site oficial em WebView, não um cliente alternativo nem uma API que baixa vídeos. Os requisitos do player e do conteúdo continuam aplicáveis.

## Verificação

Este pacote contém o projeto-fonte, não um APK já compilado. O ambiente que preparou este ZIP não contém Android SDK/Gradle instalados, portanto não foi possível compilar, instalar ou testar em hardware nesta sessão. O primeiro build precisa ser feito no Android Studio, com internet para baixar dependências e o modelo MediaPipe.
