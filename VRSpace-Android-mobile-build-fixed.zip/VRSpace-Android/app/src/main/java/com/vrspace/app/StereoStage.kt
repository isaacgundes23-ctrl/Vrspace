package com.vrspace.app

import android.content.Context
import android.view.MotionEvent
import android.widget.FrameLayout

/**
 * Renders the whole mixed-reality scene twice, side-by-side, for a Cardboard-style
 * viewer. This is a duplicated flat interface (not true depth/stereoscopic 3D).
 * Touches on either eye are translated back into the same logical screen space.
 */
class StereoStage(context: Context) : FrameLayout(context) {
    var stereoMode: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    override fun dispatchDraw(canvas: android.graphics.Canvas) {
        if (!stereoMode || width == 0) {
            super.dispatchDraw(canvas)
            return
        }

        val half = width / 2f
        var save = canvas.save()
        canvas.clipRect(0f, 0f, half, height.toFloat())
        canvas.scale(0.5f, 1f)
        super.dispatchDraw(canvas)
        canvas.restoreToCount(save)

        save = canvas.save()
        canvas.clipRect(half, 0f, width.toFloat(), height.toFloat())
        canvas.translate(half, 0f)
        canvas.scale(0.5f, 1f)
        super.dispatchDraw(canvas)
        canvas.restoreToCount(save)
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (!stereoMode || width == 0) return super.dispatchTouchEvent(event)
        val copy = MotionEvent.obtain(event)
        val half = width / 2f
        val logicalX = if (event.x < half) event.x * 2f else (event.x - half) * 2f
        copy.setLocation(logicalX.coerceIn(0f, width.toFloat()), event.y)
        val handled = super.dispatchTouchEvent(copy)
        copy.recycle()
        return handled
    }

    /** Injects a hand pinch as a tap in logical scene coordinates. */
    fun tapFromHand(x: Float, y: Float) {
        val now = android.os.SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(now, now, MotionEvent.ACTION_DOWN, x, y, 0)
        val up = MotionEvent.obtain(now, now + 55, MotionEvent.ACTION_UP, x, y, 0)
        // Call the superclass so stereo coordinate remapping is not applied twice.
        super.dispatchTouchEvent(down)
        super.dispatchTouchEvent(up)
        down.recycle()
        up.recycle()
    }
}
