package com.vrspace.app

import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import android.util.Log
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker

/** CameraX frame analyzer backed by Google's on-device MediaPipe Hand Landmarker. */
class HandTrackingAnalyzer(
    private val landmarker: HandLandmarker,
    private val overlay: HandOverlayView
) : ImageAnalysis.Analyzer {
    override fun analyze(image: ImageProxy) {
        var source: Bitmap? = null
        var rotated: Bitmap? = null
        try {
            source = image.toBitmap()
            val rotation = image.imageInfo.rotationDegrees
            if (rotation == 0) {
                rotated = source
            } else {
                val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
                rotated = Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
            }

            val mpImage = BitmapImageBuilder(rotated).build()
            val result = landmarker.detectForVideo(mpImage, SystemClock.uptimeMillis())
            val hands = result.landmarks().map { hand ->
                hand.map { point -> point.x() to point.y() }
            }
            overlay.post { overlay.updateHands(hands) }
        } catch (error: Exception) {
            Log.e("VRSpace", "Falha ao analisar quadro da câmera", error)
        } finally {
            image.close()
            if (rotated != null && rotated !== source) rotated?.recycle()
            source?.recycle()
        }
    }
}
