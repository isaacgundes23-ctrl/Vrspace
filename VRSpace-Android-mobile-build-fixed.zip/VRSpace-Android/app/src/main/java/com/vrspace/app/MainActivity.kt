package com.vrspace.app

import android.Manifest
import androidx.activity.ComponentActivity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.net.URLEncoder
import java.util.concurrent.Executors
import kotlin.math.max

class MainActivity : ComponentActivity() {
    private lateinit var stage: StereoStage
    private lateinit var preview: PreviewView
    private lateinit var windowHost: FrameLayout
    private lateinit var dock: LinearLayout
    private lateinit var handOverlay: HandOverlayView
    private lateinit var keyboardPanel: LinearLayout
    private lateinit var keyboardText: TextView
    private lateinit var cameraController: LifecycleCameraController
    private var landmarker: HandLandmarker? = null
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val openWindows = mutableListOf<WindowPanel>()
    private var activePanel: WindowPanel? = null
    private val typedText = StringBuilder()
    private var showPassthrough = true

    companion object { private const val CAMERA_PERMISSION_REQUEST = 7104 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)

        buildScene()
        stage.post { openWindow("DuckDuckGo", "https://duckduckgo.com") }
        requestCameraAndStart()
    }

    private fun buildScene() {
        stage = StereoStage(this).apply { setBackgroundColor(Color.rgb(3, 7, 16)) }
        preview = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.PERFORMANCE
        }
        stage.addView(preview, FrameLayout.LayoutParams(-1, -1))

        // Darken the camera feed slightly so translucent MR panels remain legible.
        val tint = View(this).apply { setBackgroundColor(0x55040b18) }
        stage.addView(tint, FrameLayout.LayoutParams(-1, -1))

        windowHost = FrameLayout(this)
        stage.addView(windowHost, FrameLayout.LayoutParams(-1, -1))

        val dockScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(0xdd07101d.toInt())
            clipToPadding = false
        }
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        dockScroll.addView(dock, ViewGroup.LayoutParams(-2, -1))
        stage.addView(dockScroll, FrameLayout.LayoutParams(-1, dp(58), Gravity.TOP))

        addDockButton("⌂ INÍCIO") { openWindow("DuckDuckGo", "https://duckduckgo.com") }
        addDockButton("PESQUISA") { openWindow("DuckDuckGo", "https://duckduckgo.com") }
        addDockButton("YOUTUBE") { openWindow("YouTube", "https://www.youtube.com") }
        addDockButton("JOGOS") { openWindow("Jogos HTML5", "https://itch.io/games/html5") }
        addDockButton("＋ JANELA") { openWindow("Nova janela", "https://duckduckgo.com") }
        addDockButton("⌨ TECLADO") { toggleKeyboard() }
        addDockButton("VR / MR") {
            stage.stereoMode = !stage.stereoMode
            Toast.makeText(this, if (stage.stereoMode) "Modo VR: duas imagens" else "Modo MR: tela flutuante", Toast.LENGTH_SHORT).show()
        }
        addDockButton("CÂMERA") {
            showPassthrough = !showPassthrough
            preview.visibility = if (showPassthrough) View.VISIBLE else View.INVISIBLE
        }

        keyboardPanel = buildVirtualKeyboard().apply { visibility = View.GONE }
        val keyboardParams = FrameLayout.LayoutParams(-1, dp(190), Gravity.BOTTOM)
        stage.addView(keyboardPanel, keyboardParams)

        handOverlay = HandOverlayView(this).apply {
            onPinch = { x, y -> stage.tapFromHand(x, y) }
            isClickable = false
        }
        stage.addView(handOverlay, FrameLayout.LayoutParams(-1, -1))
        setContentView(stage)
    }

    private fun addDockButton(label: String, action: () -> Unit) {
        val button = TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(15), dp(8), dp(15), dp(8))
            background = rounded(0xff17283d.toInt(), 28)
            isFocusable = true
            setOnClickListener { action() }
        }
        val params = LinearLayout.LayoutParams(-2, dp(42)).apply {
            marginStart = dp(5); marginEnd = dp(5)
        }
        dock.addView(button, params)
    }

    private fun openWindow(title: String, url: String) {
        if (openWindows.size >= 4) {
            Toast.makeText(this, "Limite de 4 janelas. Feche uma para abrir outra.", Toast.LENGTH_SHORT).show()
            return
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0xee101a2b.toInt(), 22).apply {
                setStroke(dp(1), 0xff45617f.toInt())
            }
            elevation = dp(18).toFloat()
            clipToOutline = true
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(5), dp(8), dp(5))
            setBackgroundColor(0xff16263b.toInt())
        }
        val titleView = TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(Color.WHITE)
            isSingleLine = true
        }
        header.addView(titleView, LinearLayout.LayoutParams(0, dp(42), 1f))
        val back = smallHeaderButton("‹")
        val forward = smallHeaderButton("›")
        val reload = smallHeaderButton("↻")
        val close = smallHeaderButton("×")
        header.addView(back); header.addView(forward); header.addView(reload); header.addView(close)

        val web = WebView(this).apply {
            setBackgroundColor(Color.rgb(248, 250, 253))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.mediaPlaybackRequiresUserGesture = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val scheme = request.url.scheme ?: return true
                    return scheme != "https" && scheme != "http"
                }
            }
            webChromeClient = WebChromeClient()
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
        }
        back.setOnClickListener { if (web.canGoBack()) web.goBack() }
        forward.setOnClickListener { if (web.canGoForward()) web.goForward() }
        reload.setOnClickListener { web.reload() }

        panel.addView(header, LinearLayout.LayoutParams(-1, dp(48)))
        panel.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        val record = WindowPanel(title, url, panel, web)
        close.setOnClickListener { closeWindow(record) }
        header.setOnClickListener { bringToFront(record) }

        val w = max(dp(320), (resources.displayMetrics.widthPixels * 0.84f).toInt())
        val h = max(dp(250), (resources.displayMetrics.heightPixels * 0.72f).toInt())
        val offset = openWindows.size * dp(24)
        val params = FrameLayout.LayoutParams(w, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(76) + offset
            leftMargin = offset
        }
        windowHost.addView(panel, params)
        openWindows.add(record)
        activePanel = record
        web.loadUrl(url)
        bringToFront(record)
    }

    private fun bringToFront(panel: WindowPanel) {
        activePanel = panel
        panel.root.bringToFront()
        panel.root.alpha = 1f
        handOverlay.bringToFront()
    }

    private fun closeWindow(panel: WindowPanel) {
        panel.web.stopLoading()
        panel.web.destroy()
        windowHost.removeView(panel.root)
        openWindows.remove(panel)
        activePanel = openWindows.lastOrNull()
        activePanel?.root?.bringToFront()
        handOverlay.bringToFront()
    }

    private fun smallHeaderButton(label: String): TextView = TextView(this).apply {
        text = label
        textSize = 19f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setPadding(dp(8), 0, dp(8), 0)
        isClickable = true
    }

    private fun buildVirtualKeyboard(): LinearLayout {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(0xf0121d30.toInt(), 18).apply { setStroke(dp(1), 0xff45617f.toInt()) }
            elevation = dp(24).toFloat()
        }
        keyboardText = TextView(this).apply {
            text = "Digite uma pesquisa…"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = rounded(0xff25354c.toInt(), 8)
        }
        panel.addView(keyboardText, LinearLayout.LayoutParams(-1, dp(34)))
        addKeyRow(panel, listOf("Q","W","E","R","T","Y","U","I","O","P"))
        addKeyRow(panel, listOf("A","S","D","F","G","H","J","K","L"))
        addKeyRow(panel, listOf("Z","X","C","V","B","N","M","ESPAÇO","⌫","BUSCAR"))
        return panel
    }

    private fun addKeyRow(parent: LinearLayout, keys: List<String>) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for (key in keys) {
            val view = TextView(this).apply {
                text = key
                textSize = if (key.length > 1) 10f else 14f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = rounded(if (key == "BUSCAR") 0xff176a9b.toInt() else 0xff263a55.toInt(), 7)
                setOnClickListener {
                    when (key) {
                        "⌫" -> if (typedText.isNotEmpty()) typedText.deleteCharAt(typedText.length - 1)
                        "ESPAÇO" -> typedText.append(' ')
                        "BUSCAR" -> submitVirtualSearch()
                        else -> typedText.append(key.lowercase())
                    }
                    keyboardText.text = typedText.toString().ifBlank { "Digite uma pesquisa…" }
                }
            }
            val lp = LinearLayout.LayoutParams(0, dp(34), if (key == "ESPAÇO") 2f else 1f).apply {
                marginStart = dp(2); marginEnd = dp(2); topMargin = dp(5)
            }
            row.addView(view, lp)
        }
        parent.addView(row, LinearLayout.LayoutParams(-1, dp(39)))
    }

    private fun submitVirtualSearch() {
        val query = typedText.toString().trim()
        if (query.isBlank()) return
        val encoded = URLEncoder.encode(query, "UTF-8")
        val panel = activePanel
        val destination = when (panel?.title) {
            "YouTube" -> "https://www.youtube.com/results?search_query=$encoded"
            "Jogos HTML5" -> "https://itch.io/search?q=$encoded"
            else -> "https://duckduckgo.com/?q=$encoded"
        }
        if (panel != null) panel.web.loadUrl(destination) else openWindow("DuckDuckGo", destination)
        typedText.clear()
        keyboardText.text = "Digite uma pesquisa…"
        keyboardPanel.visibility = View.GONE
    }

    private fun toggleKeyboard() {
        keyboardPanel.visibility = if (keyboardPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        handOverlay.bringToFront()
    }

    private fun requestCameraAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCameraAndHandTracking()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST)
        }
    }

    private fun startCameraAndHandTracking() {
        try {
            val base = BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build()
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.VIDEO)
                .setNumHands(2)
                .setMinHandDetectionConfidence(0.55f)
                .setMinHandPresenceConfidence(0.55f)
                .setMinTrackingConfidence(0.50f)
                .build()
            landmarker = HandLandmarker.createFromOptions(this, options)

            cameraController = LifecycleCameraController(this).apply {
                cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                imageAnalysisBackpressureStrategy = ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
                setImageAnalysisAnalyzer(cameraExecutor, HandTrackingAnalyzer(landmarker!!, handOverlay))
            }
            preview.controller = cameraController
            cameraController.bindToLifecycle(this@MainActivity)
        } catch (error: Exception) {
            Toast.makeText(this, "Não foi possível iniciar o hand tracking: ${error.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startCameraAndHandTracking()
            } else {
                Toast.makeText(this, "Sem a câmera, DuckDuckGo, YouTube e jogos funcionam, mas passthrough e hand tracking ficam desligados.", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroy() {
        try { cameraController.clearImageAnalysisAnalyzer() } catch (_: Exception) { }
        openWindows.forEach { it.web.stopLoading(); it.web.destroy() }
        landmarker?.close()
        cameraExecutor.shutdown()
        super.onDestroy()
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private data class WindowPanel(
        val title: String,
        val initialUrl: String,
        val root: LinearLayout,
        val web: WebView
    )
}
