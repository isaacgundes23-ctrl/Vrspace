package com.vrspace.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Draws MediaPipe's 21 hand landmarks and detects a thumb/index pinch. */
class HandOverlayView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var hands: List<List<Pair<Float, Float>>> = emptyList()
    private var pinchWasDown = false
    var onPinch: ((Float, Float) -> Unit)? = null
    var status: String = "Aguardando mãos…"
        private set

    fun updateHands(newHands: List<List<Pair<Float, Float>>>) {
        hands = newHands
        status = if (newHands.isEmpty()) "Mostre as mãos para a câmera" else "${newHands.size} mão(s) detectada(s)"
        invalidate()
        val first = newHands.firstOrNull()
        if (first != null && first.size > 8) {
            val thumb = first[4]
            val index = first[8]
            val dx = (thumb.first - index.first).toDouble()
            val dy = (thumb.second - index.second).toDouble()
            val distance = kotlin.math.sqrt(dx * dx + dy * dy)
            val pinching = distance < 0.055f
            if (pinching && !pinchWasDown) onPinch?.invoke(index.first * width, index.second * height)
            pinchWasDown = pinching
        } else {
            pinchWasDown = false
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.color = 0xff41e6ff.toInt()
        val links = arrayOf(
            intArrayOf(0,1,2,3,4), intArrayOf(0,5,6,7,8),
            intArrayOf(5,9,10,11,12), intArrayOf(9,13,14,15,16),
            intArrayOf(13,17,18,19,20), intArrayOf(0,17)
        )
        for (hand in hands) {
            for (link in links) {
                for (i in 0 until link.size - 1) {
                    val a = hand[link[i]]; val b = hand[link[i + 1]]
                    canvas.drawLine(a.first * width, a.second * height, b.first * width, b.second * height, paint)
                }
            }
            paint.style = Paint.Style.FILL
            for (point in hand) canvas.drawCircle(point.first * width, point.second * height, 5f, paint)
            paint.style = Paint.Style.STROKE
        }
        paint.style = Paint.Style.FILL
        paint.color = 0xffeafaff.toInt()
        paint.textSize = 28f
        canvas.drawText(status, 28f, height - 28f, paint)
    }
}
